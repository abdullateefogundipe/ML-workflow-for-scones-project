import json
import os
import io
import boto3
import base64


# Fill this in with the name of your deployed model
ENDPOINT_NAME = 'image-classification-2021-12-23-14-11-59-836' ## TODO: fill in

runtime = boto3.Session().client('sagemaker-runtime')

def lambda_handler(event, context):

    # Decode the image data
    image = base64.b64decode(event['body']['image_data']) ## TODO: fill in)

    # Instantiate a Predictor
    response = runtime.invoke_endpoint(EndpointName = ENDPOINT_NAME, Body = image, ContentType ='image/png' )
    
    
    # Make a prediction:
    inferences = response['Body'].read()
    

    # We return the data back to the Step Function    
    event["inferences"] = inferences.decode('utf-8')
    
    return {
        'statusCode': 200,
        'body': json.dumps(event)
    }
    
